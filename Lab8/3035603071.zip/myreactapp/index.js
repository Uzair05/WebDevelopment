import React from 'react';
import ReactDOM from 'react-dom';
import ContactPage from './App';

ReactDOM.render(
  <ContactPage/>,
  document.getElementById('root')
);
