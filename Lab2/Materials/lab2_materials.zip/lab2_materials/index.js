function loadPage(){
	removeElement();
	loadEvents();
	loadFooter();
	styleSearchButton();


}

function removeElement(){

}

function loadEvents(){
	
}

function loadFooter(){
		

}

function styleSearchButton(){

}

function inputValidation(event){


}