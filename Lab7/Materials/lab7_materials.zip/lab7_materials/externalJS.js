var contactListApp = angular.module('contactList', []);

contactListApp.controller('contactListController', function($scope, $http){

    //to be completed

});

