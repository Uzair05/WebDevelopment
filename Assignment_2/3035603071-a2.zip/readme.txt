copy the files into their respective directories (MyApp & AlbumService)
Run the database MongoDb and launch the react app MyApp using command
'npm start'

The program is as modulated as I could make it, this ensures that it easy to maintain and update.

The react application (App.js) makes use of conditional rendering based on whether or not the state variable 'loggedIn' has been set to true, this will enable the react app to display the webpage according to the login conditions.
Wherever possible efforts were made to reduce the need of redundant and noisy code.

Future plannings for the react application involves further dividing the individual subsections into distinct classes to further promote ease of maintainance and reusibility.
Another Future planning is to include comment blocks to allow for easier documentation and undestanding.

