import React from 'react';
import ReactDOM from 'react-dom';
import './App.css';
import $ from 'jquery';


class LoggedOut extends React.Component {
  constructor(props) {
    super(props);
    this.handleUsernameChange = this.handleUsernameChange.bind(this);
    this.handlePasswordChange = this.handlePasswordChange.bind(this);
    this.handleLogin = this.handleLogin.bind(this);
  }

  handleUsernameChange(){
    var name = document.getElementById("username").value;
    this.props.handleUsernameChange(name);
  }

  handlePasswordChange(){
    var password = document.getElementById("password").value;
    this.props.handlePasswordChange(password);
  }

  handleLogin(){
    this.props.handleLogin();
  }

  render(){
    return(
      <div className="Login">
        Username:<input type="text" name="UserID" id="username" onChange={this.handleUsernameChange}/><br/>
        Password:<input type="password" name="UserPass" id="password" onChange={this.handlePasswordChange}/><br/>
        <input type="submit" value="Login" onClick={this.handleLogin}/>
      </div>
    );
  };

}
class UserRow extends React.Component {
  constructor(props) {
    super(props);
    this.loadAlbum = this.loadAlbum.bind(this);
  }

  loadAlbum(id){
    this.props.loadAlbum(id);
  }

  render(){
    const friend = this.props.friend;

    return(
      <div id="Users">
        <p onClick={this.loadAlbum(friend._id)} id={friend._id}>{friend.username}\'s Album</p>
      </div>
    );
  }

}


class LoggedIn extends React.Component {
  constructor(props) {
    super(props);
    this.handleLogout = this.handleLogout.bind(this);
    this.loadAlbum = this.loadAlbum.bind(this);
  }

  loadAlbum(id){
    this.props.loadAlbum(id);
  }
  handleLogout(){
    this.props.handleLogout();
  }

  render(){

    let rows = [];

    this.state.friends.map((friend)=>{
      rows.push(
        <UserRow
          friend={friend}
          loadAlbum = {this.loadAlbum}
        />
      );
    })


    return(
      <div>
        <input type="submit" value="Log Out" className="Logout" onClick={this.handleLogout} />
        <div id="Users" className="UsersBar">
          <p>{rows}</p>
        </div>
        <div id="Photos">

        </div>
      </div>
    );
  }

}

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      username:"",
      password:"",
      userId:"",
      loggedIn:false,
      friends:[],
      album:[]
    };
    this.handleUsernameChange = this.handleUsernameChange.bind(this);
    this.handlePasswordChange = this.handlePasswordChange.bind(this);
    this.handleLogin = this.handleLogin.bind(this);
    this.loadAlbum = this.loadAlbum.bind(this);
    this.handleLogout = this.handleLogout.bind(this);

  }


  loadAlbum(id){
    $.ajax({
      url: ("http://localhost:3002/getAlbum/" + id),
      type: "GET",
      dataType: 'json',
      success: function(data) {
        this.setState({
          album:data
        });
      }.bind(this),
        error: function (xhr, ajaxOptions, thrownError) {
            alert(xhr.status);
            alert(thrownError);
        }.bind(this)
    });
  }
  handleUsernameChange(name){
    this.setState({
      username:name
    });
  }
  handlePasswordChange(pass){
    this.setState({
      password:pass
    });
  }
  handleLogin(){
    $.ajax({
      url: ("http://localhost:3002/login"),
      type: "POST",
      data: {'username':this.state.username, 'password':this.state.password},
      dataType: 'json',
      success: function(data) {
        this.setState({
          friends:data,
          loggedIn:true
        });
      }.bind(this),
        error: function (xhr, ajaxOptions, thrownError) {
            alert("Loggin Failed");
            alert("Loggin Failed");
        }.bind(this)
    });
  }
  handleLogout(){
    $.ajax({
      url: ("http://localhost:3002/logout"),
      type: "GET",
      dataType: 'json',
      success: function(data) {
        this.setState({
          loggedIn:false
        });
      }.bind(this),
        error: function (xhr, ajaxOptions, thrownError) {
            alert(xhr.status);
            alert(thrownError);
        }.bind(this)
    });
  }


  render(){
    if(this.state.loggedIn == true){
      return(
        <div id="MainAlbum" className = "HeaderSpace">
          <h1>iAlbum</h1>
          <LoggedIn
            handleLogout = {this.handleLogout}
            loadAlbum = {this.loadAlbum}
            friends = {this.state.friends}
          />

        </div>
      );
    }else{
      return(
        <div id="MainAlbum" className = "HeaderSpace">
          <h1>iAlbum</h1>
          <LoggedOut
            handleUsernameChange = {this.handleUsernameChange}
            handlePasswordChange = {this.handlePasswordChange}
            handleLogin = {this.handleLogin}
          />
        </div>
      );
    }
  }
}

export default App;
