var express = require('express');
var router = express.Router();
const fs = require('fs');
var cors = require('cors');
var cookieParser = require('cookie-parser');
router.use(cookieParser()); /*Implement cookies in the end*/


/*Redirect Empty GET requests (Debugging purposes)*/
router.get('/',cors(),function(req,res){
  res.redirect('/init');
});
/*Handle GET init requests*/
router.get('/init',cors(),function(req,res){
  var db = req.db;
  var collection = db.get("userList");

  if(req.cookies.userID !== undefined){
    var userID = req.cookies.userID;
    collection.find({'username': userID},{},function(err, docs){
      if (err === null){
        //var resp = [{"username":docs[0].username, "_id":docs[0]._id}];
        var resp = [];
        var friends = docs[0].friends;
          for(var i=0;i<friends.length;i++){
            collection.find({'username': friends[i]},{},function(err2, doc2){
              if (err2 === null){
                resp.push({"username":doc2[0].username, "_id":doc2[0]._id});
                if (resp.length == friends.length){
                  var data = {"username":userID, "friends":resp};
                  res.json(data);
                }
              }else{
                res.send({msg:err2});
              }
            });
          }
      }else{
          res.send({msg: err});
        }
    });
  }else{
    res.send("");
  }
});
/*Handle POST login requests*/
router.post('/login',cors(),function(req,res){
  var username = req.body.username;
  var password = req.body.password;
  var db = req.db;
  var collection = db.get("userList");

  collection.find({"username":username},{},function(err,docs){
    if (err === null){
      if (docs[0].password == password){
        res.cookie("userID",docs[0]._id,{ maxAge: 3600000});
        var friends = docs[0].friends;
        var resp = [];
        for(var i=0;i<friends.length;i++){
          collection.find({"username":friends[i]},{},function(err2,doc2){
            if (err2 === null){
              resp.push({"username":doc2[0].username, "_id":doc2[0]._id});
              if (resp.length == friends.length){
                res.json(resp);
              }
            }else{
              res.send({msg: err2});
            }
          });
        }

      }else{
        res.send("Login Failure");
      }
    }else{
      res.send({msg: err});
    }
  });
});
/*Handle GET logout requests*/
router.get('/logout',cors(),function(req,res){
  res.clearCookie(req.cookies.userID);
  res.json("");
});
/*Handle GET getalbum requests*/
router.get('/getalbum/:userid',cors(),function(req,res){
  var db = req.db;
  var collection = db.get("photoList");
  var userID = req.param.userid;
  if (userID == '0'){
    userID = req.cookie.userid;
  }

  collection.find({"userid":userID},{},function(err,docs){
    if(err === null){
      var resp = [];
      for(var i=0;i<docs.length;i++){
        resp.push({"url":docs[i].url, "_id":docs[i]._id, "likedby":docs[i].likedby});
        if (resp.length == docs.length){
          console.log(resp);
          res.json(resp);
        }
      }
    }else{
      res.send({msg:err});
    }
  });

});
/*POST to upload photos*/
router.post('/uploadphoto',cors(),function(req,res){
  var userID=req.cookies.userID;
  var db = req.db;
  var collection=db.get("photoList");
  var xName = Math.floor(Math.random() * 1000) + 1;
  var writeStream = fs.createWriteStream('./public/uploads/'+xName+'.jpg');
  req.pipe(writeStream);

  collection.insert({'url': 'http://localhost:3002/uploads/'+ xName +'.jpg', 'userid': userID, 'likedby':[]},function(er,dos){
    if(er === null){
      collection.find({'url': 'http://localhost:3002/uploads/'+ xName +'.jpg', 'userid': userID}, function(err,docs){
        if(docs.length>0){
          res.json(docs);
        }else{
          res.send({msg:err});
        }
      });
    }
  });
});
/*DELETE to delete photos*/
router.delete('/deletephoto/:photoid',cors(),function(req,res){
  var photoID = req.params.photoid;
  var db = req.db;
  var collection=db.get("photoList");

  collection.find({"_id":photoID},{},function(err,docs){
    if(err===null){
      var nameULR = docs[0].url;
      var nameURLpieces = nameURL.split('/');
      var nameFile = nameURLpieces[nameURLpieces.length - 1];

      fs.unlink("./public/uploads/" + nameFile, (err1) => {
        if(err1 === null){
          collection.remove({"_id":photoID},function(err2,docs2){
            if(err2 === null){
              res.send("");
              console.log("./public/uploads/" + nameFile +' was deleted');
            }else{
              res.send({msg:err2});
            }

          });
        }
      });
    }
  });
});

/*PUT to update likes*/
router.put('/updatelike/:photoid',cors(),function(req,res){
  var photoID = req.params.photoid;
  var userID = req.cookies.userID;
  var db = req.db;
  var photoCollection = db.get("photoList");
  var userCollection = db.get("userList");

  //{ $set: {"name": req.body.name, "tel": req.body.tel, "email": req.body.email}}

  userCollection.find({"_id":userID},{},function(err,docs){
    if (err===null){
      var username = docs[0].username;
      var resp;
      photoCollection.find({"_id":photoID},{},function(err3,dos3){
        if(err3 === null){
          resp = docs3[0].likedby;
          resp.push(username);
          photoCollection.update({"_id":photoID},{ $set: {'likedby':resp}},function(err2,docs2){
            if (err2 === null){
              res.json(resp);
            }else{
              res.send({msg:err2});
            }
          });
        }else{
          res.send({msg:err3});
        }
      });
    }else{
      res.send({msg:err});
    }
  });


});


router.options("/*", cors());
module.exports = router;
