import React from 'react';
import ReactDOM from 'react-dom';
import Album from './App';

ReactDOM.render(
  <Album/>,
  document.getElementById('root')
);
